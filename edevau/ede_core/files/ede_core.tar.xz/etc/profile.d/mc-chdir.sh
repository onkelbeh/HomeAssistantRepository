#!/bin/sh
if [ /usr/libexec/mc/mc.sh ]; then
    . /usr/libexec/mc/mc.sh
fi
