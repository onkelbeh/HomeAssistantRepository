#/bin/bash

function _my_emerge(){
    /usr/bin/emerge $*
    echo "$*"|grep -q "u" && /usr/sbin/restart_services -l
}

alias emerge='_my_emerge'

alias ..='cd ..'
alias ...='cd ../..'
alias ....='cd ../../..'
alias .....='cd ../../../..'
alias ......='cd ../../../../..'
alias .......='cd ../../../../../..'
alias ........='cd ../../../../../../..'
alias beep='echo -en "\007"'
alias cd..='cd ..'
alias dir='ls -l'
alias du='du -hsc'
alias egrep='egrep --color=auto'
alias fgrep='fgrep --color=auto'
alias grep='grep --color=auto'
alias l='ls -alF --color=auto'
alias la='ls -la --color=auto'
alias ll='ls -l --color=auto'
alias ls='ls $LS_OPTIONS --color=auto'
alias ls-l='ls -l --color=auto'

alias ema='emacs'

alias emacs='export EDITOR="/usr/bin/emacs";emacs'
alias nano='export EDITOR="/usr/bin/nano";nano'
alias vi='export EDITOR="/usr/bin/vi";vi'


while read s;do
    alias rc$s="/sbin/service ${s}"
done < <(/sbin/service -l)


export CCACHE_DIR="/var/tmp/ccache"
export CCACHE_SIZE="10G"

PS_MY_HOSTNAME="$(/bin/hostname -f|/bin/sed "s/.in.edevau.net//")"

case ${TERM} in
    screen*)
	export PS1='$( ret=$? ; test $ret -gt 0 && echo "\[\e[41;93m\]   [$ret]   \[\e[0m\]" )\[\033k\u@'${PS_MY_HOSTNAME}':\w\033\\\]\[\033[01;31m\]\u@'${PS_MY_HOSTNAME}':\[\033[01;34m\]\w \$\[\033[00m\] '
	;;
    *)
	export PS1='$( ret=$? ; test $ret -gt 0 && echo "\[\e[41;93m\]   [$ret]   \[\e[0m\]" )\[\033[01;31m\]\u@'${PS_MY_HOSTNAME}':\[\033[01;34m\]\w \$\[\033[00m\] '
	;;
esac
unset PS_MY_HOSTNAME

export http_proxy=ampx.in.edevau.net:3128
export https_proxy=ampx.in.edevau.net:3128
export ftp_proxy=ampx.in.edevau.net:3128
